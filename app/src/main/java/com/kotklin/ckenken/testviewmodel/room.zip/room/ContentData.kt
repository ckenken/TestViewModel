package com.kotklin.ckenken.testviewmodel.room

data class ContentData(val content: String, val title: String)